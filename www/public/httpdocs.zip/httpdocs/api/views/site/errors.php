<?php
var_dump($result);
//var_dump($exception);

//echo $exception->xdebug_message;
die();

