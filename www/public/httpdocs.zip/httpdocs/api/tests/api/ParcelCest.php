<?php


class ParcelCest
{
    public function _before(ApiTester $I)
    {
    }

    public function _after(ApiTester $I)
    {
    }

    // tests
    public function testGetList(ApiTester $I)
    {
//        $I->sendAutoAuthGET('v1/parcel/get-list/'.TEST_ID_GIFT.'/0/10');
//        $I->seeResponseSuccessTrue();
    }
}
