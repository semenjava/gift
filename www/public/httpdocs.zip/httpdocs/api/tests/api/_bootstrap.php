<?php
include dirname(__DIR__) . '/const.php';

