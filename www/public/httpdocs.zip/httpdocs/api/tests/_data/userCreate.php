<?php

return [
    [
        'username' => time().'.test',
        'password_hash' => '123456',
        'email' => 'test@test@sch'.time().'ultz.info',
    ],
];
