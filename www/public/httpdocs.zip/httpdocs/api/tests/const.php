<?php
const TEST_ID = '2';
const TEST_USERNAME = 'user2@user2.com';//'user2@user2.com';//'user1@user1.com';
const TEST_PSWD = '123456';

const TEST_DATES_ID = '10';
const TEST_ID_GIFT_RECIEVER = '2';
const TEST_ID_GIFT= '2';
const IS_DEV = 1;

const ID_USER = 2;

const ID_DATE_DESC = 12;

const V = 'v1_1';










