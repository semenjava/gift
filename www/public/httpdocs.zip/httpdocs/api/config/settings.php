<?php

// Agreement Url
define ('FRONTEND_BASE_URL', '/sZoo');
