<?php

// Agreement Url
define ('FRONTEND_BASE_URL', '/sZoo');
defined('FACEBOOK_APP_ID') or define('FACEBOOK_APP_ID', '1823884954535879');
defined('FACEBOOK_APP_SECRET') or define('FACEBOOK_APP_SECRET', '8668f477e3da1f578f0609e640566300');